# Kartikey-C-69-Project
Bar Code Scanner App